"""
Explainability module for generating explanations of system decisions.
"""
import logging
from typing import Dict, Any, List
from .utils import logger


class ExplainabilityModule:
    """Generate explanations for agent decisions and code generation."""
    
    def __init__(self):
        """Initialize explainability module."""
        logger.info("ExplainabilityModule initialized")
    
    def explain_code_generation(self, user_input: str, generated_code: str, 
                               intent: Dict[str, Any]) -> str:
        """Explain how code was generated from user input."""
        explanation = []
        explanation.append("=== Code Generation Explanation ===\n")
        explanation.append(f"User Request: {user_input}\n")
        
        if intent:
            explanation.append(f"Extracted Intent:")
            explanation.append(f"  - Functionality: {intent.get('functionality', 'N/A')}")
            explanation.append(f"  - Components: {', '.join(intent.get('components', []))}")
            explanation.append(f"  - Security Requirements: {', '.join(intent.get('security_requirements', []))}")
        
        explanation.append(f"\nGenerated Code:")
        explanation.append(f"  - Lines: {len(generated_code.split(chr(10)))}")
        explanation.append(f"  - Characters: {len(generated_code)}")
        explanation.append(f"  - Security-focused: Yes (enforced by system prompts)")
        
        return "\n".join(explanation)
    
    def explain_agent_decision(self, decision: str, context: Dict[str, Any]) -> str:
        """Explain agent's decision-making process."""
        explanation = []
        explanation.append("=== Agent Decision Explanation ===\n")
        explanation.append(f"Decision: {decision}\n")
        explanation.append(f"Context:")
        explanation.append(f"  - Iteration: {context.get('iteration', 'N/A')}")
        explanation.append(f"  - Vulnerabilities Found: {context.get('vulnerability_count', 0)}")
        explanation.append(f"  - High Severity Issues: {context.get('high_severity_count', 0)}")
        
        if decision == "ACCEPT":
            explanation.append(f"\nReasoning: Code is secure or maximum iterations reached.")
        elif decision == "FIX":
            explanation.append(f"\nReasoning: High-severity vulnerabilities detected. Agent will fix and re-audit.")
        elif decision == "REGENERATE":
            explanation.append(f"\nReasoning: Too many vulnerabilities. Generating new code from scratch.")
        
        return "\n".join(explanation)
    
    def explain_vulnerability(self, vulnerability: Dict[str, Any]) -> str:
        """Explain a detected vulnerability."""
        explanation = []
        explanation.append(f"=== Vulnerability Explanation ===\n")
        explanation.append(f"Type: {vulnerability.get('type', 'Unknown')}")
        explanation.append(f"Severity: {vulnerability.get('severity', 'Unknown')}")
        explanation.append(f"Line: {vulnerability.get('line', 'N/A')}")
        explanation.append(f"\nDescription: {vulnerability.get('description', 'N/A')}")
        explanation.append(f"Code Snippet: {vulnerability.get('code_snippet', 'N/A')}")
        explanation.append(f"\nFix Suggestion: {vulnerability.get('fix_suggestion', 'N/A')}")
        
        return "\n".join(explanation)
    
    def explain_security_score(self, score: int, vulnerabilities: List[Dict[str, Any]]) -> str:
        """Explain security score calculation."""
        explanation = []
        explanation.append("=== Security Score Explanation ===\n")
        explanation.append(f"Score: {score}/100\n")
        
        if score >= 90:
            explanation.append("Rating: Excellent - Code is highly secure")
        elif score >= 70:
            explanation.append("Rating: Good - Minor security improvements possible")
        elif score >= 50:
            explanation.append("Rating: Fair - Some security concerns present")
        else:
            explanation.append("Rating: Poor - Significant security issues detected")
        
        explanation.append(f"\nVulnerabilities Breakdown:")
        severity_counts = {}
        for vuln in vulnerabilities:
            severity = vuln.get('severity', 'unknown')
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
        
        for severity, count in severity_counts.items():
            explanation.append(f"  - {severity.upper()}: {count}")
        
        explanation.append(f"\nCalculation: Base score (100) minus penalties for vulnerabilities")
        
        return "\n".join(explanation)
    
    def generate_full_explanation(self, result: Dict[str, Any]) -> str:
        """Generate comprehensive explanation of entire process."""
        explanation = []
        explanation.append("=" * 60)
        explanation.append("COMPLETE SYSTEM EXPLANATION")
        explanation.append("=" * 60)
        explanation.append("")
        
        # Code generation explanation
        if "user_input" in result:
            explanation.append(self.explain_code_generation(
                result["user_input"],
                result.get("code", ""),
                result.get("intent", {})
            ))
            explanation.append("")
        
        # Agent decision explanation
        if "actions_taken" in result:
            explanation.append("=== Agent Actions ===")
            for action in result["actions_taken"]:
                explanation.append(f"  - {action}")
            explanation.append("")
        
        # Vulnerability explanation
        if "vulnerabilities" in result and result["vulnerabilities"]:
            explanation.append("=== Detected Vulnerabilities ===")
            for i, vuln in enumerate(result["vulnerabilities"][:5], 1):
                explanation.append(f"\n{i}. {vuln.get('type', 'Unknown')} - {vuln.get('severity', 'Unknown')}")
                explanation.append(f"   {vuln.get('description', 'N/A')}")
            explanation.append("")
        
        # Security score explanation
        if "security_score" in result:
            explanation.append(self.explain_security_score(
                result["security_score"],
                result.get("vulnerabilities", [])
            ))
        
        return "\n".join(explanation)


# Example usage
if __name__ == "__main__":
    explainer = ExplainabilityModule()
    
    result = {
        "user_input": "Create a login function",
        "code": "def login(): pass",
        "security_score": 85,
        "vulnerabilities": []
    }
    
    print(explainer.generate_full_explanation(result))
