"""
Performance optimization module with caching and cost management.
"""
import hashlib
import json
import time
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from .utils import logger


class PerformanceOptimizer:
    """Optimize performance through caching and smart model selection."""
    
    def __init__(self, cache_enabled: bool = True, cache_ttl: int = 3600):
        """Initialize optimizer."""
        self.cache_enabled = cache_enabled
        self.cache_ttl = cache_ttl  # Time to live in seconds
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.stats = {
            "cache_hits": 0,
            "cache_misses": 0,
            "total_requests": 0,
            "total_cost": 0.0
        }
        logger.info(f"PerformanceOptimizer initialized (cache={'enabled' if cache_enabled else 'disabled'})")
    
    def get_cache_key(self, user_input: str) -> str:
        """Generate cache key from user input."""
        return hashlib.md5(user_input.encode()).hexdigest()
    
    def get_cached_result(self, user_input: str) -> Optional[Dict[str, Any]]:
        """Get cached result if available and not expired."""
        if not self.cache_enabled:
            return None
        
        cache_key = self.get_cache_key(user_input)
        
        if cache_key in self.cache:
            cached_item = self.cache[cache_key]
            cached_time = datetime.fromisoformat(cached_item["timestamp"])
            
            # Check if cache is still valid
            if datetime.now() - cached_time < timedelta(seconds=self.cache_ttl):
                self.stats["cache_hits"] += 1
                logger.info(f"Cache hit for key: {cache_key[:8]}...")
                return cached_item["result"]
            else:
                # Cache expired, remove it
                del self.cache[cache_key]
        
        self.stats["cache_misses"] += 1
        return None
    
    def cache_result(self, user_input: str, result: Dict[str, Any]) -> None:
        """Cache result for future use."""
        if not self.cache_enabled:
            return
        
        cache_key = self.get_cache_key(user_input)
        self.cache[cache_key] = {
            "result": result,
            "timestamp": datetime.now().isoformat(),
            "input": user_input[:100]  # Store first 100 chars for debugging
        }
        
        # Limit cache size (keep last 100 entries)
        if len(self.cache) > 100:
            # Remove oldest entries
            sorted_items = sorted(
                self.cache.items(),
                key=lambda x: x[1]["timestamp"]
            )
            for key, _ in sorted_items[:-100]:
                del self.cache[key]
        
        logger.info(f"Result cached with key: {cache_key[:8]}...")
    
    def estimate_cost(self, model: str, tokens: int) -> float:
        """Estimate API cost based on model and tokens."""
        # Approximate costs per 1K tokens
        costs = {
            "gemini-2.5-pro": {"input": 0.0035, "output": 0.0105},
            "gemini-2.5-flash": {"input": 0.000075, "output": 0.0003},
            "gemini-pro": {"input": 0.0005, "output": 0.0015}
        }
        
        model_costs = costs.get(model, {"input": 0.01, "output": 0.03})
        # Rough estimate: 70% input, 30% output
        input_tokens = int(tokens * 0.7)
        output_tokens = int(tokens * 0.3)
        
        cost = (input_tokens / 1000 * model_costs["input"]) + \
               (output_tokens / 1000 * model_costs["output"])
        
        return cost
    
    def should_use_cache(self, user_input: str) -> bool:
        """Determine if cache should be used for this request."""
        # Simple requests might benefit from cache
        # Complex/unique requests should bypass cache
        if len(user_input) < 50:
            return True
        return False
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics."""
        total = self.stats["cache_hits"] + self.stats["cache_misses"]
        hit_ratio = (self.stats["cache_hits"] / total * 100) if total > 0 else 0
        
        return {
            **self.stats,
            "cache_hit_ratio": f"{hit_ratio:.2f}%",
            "cache_size": len(self.cache),
            "cache_enabled": self.cache_enabled
        }
    
    def optimize_request(self, user_input: str, model: str = "gemini-2.5-pro") -> Dict[str, Any]:
        """Optimize request by checking cache and selecting best model."""
        optimization = {
            "use_cache": False,
            "recommended_model": model,
            "estimated_cost": 0.0,
            "cache_key": None
        }
        
        # Check cache
        cached = self.get_cached_result(user_input)
        if cached:
            optimization["use_cache"] = True
            optimization["cache_key"] = self.get_cache_key(user_input)
            return optimization
        
        # Model selection based on input complexity
        if len(user_input) < 100:
            # Simple request, could use cheaper model
            optimization["recommended_model"] = "gemini-2.5-flash"
        
        # Estimate cost
        estimated_tokens = len(user_input.split()) * 1.3  # Rough token estimate
        optimization["estimated_cost"] = self.estimate_cost(
            optimization["recommended_model"],
            int(estimated_tokens)
        )
        
        return optimization
    
    def clear_cache(self) -> None:
        """Clear all cached results."""
        self.cache.clear()
        logger.info("Cache cleared")
    
    def save_cache(self, filepath: str) -> None:
        """Save cache to file."""
        with open(filepath, 'w') as f:
            json.dump(self.cache, f, indent=2, default=str)
        logger.info(f"Cache saved to {filepath}")
    
    def load_cache(self, filepath: str) -> None:
        """Load cache from file."""
        try:
            with open(filepath, 'r') as f:
                self.cache = json.load(f)
            logger.info(f"Cache loaded from {filepath}")
        except FileNotFoundError:
            logger.warning(f"Cache file not found: {filepath}")


# Example usage
if __name__ == "__main__":
    optimizer = PerformanceOptimizer(cache_enabled=True)
    
    # Test caching
    test_input = "Create a login function"
    result = {"code": "def login(): pass", "score": 100}
    
    optimizer.cache_result(test_input, result)
    cached = optimizer.get_cached_result(test_input)
    
    print(f"Cached result: {cached is not None}")
    print(f"Stats: {optimizer.get_performance_stats()}")
