"""
AST (Abstract Syntax Tree) analyzer for advanced code analysis.
"""
import ast
import logging
from typing import List, Dict, Any, Set, Optional
from .utils import logger


class ASTAnalyzer:
    """Analyze code using Abstract Syntax Tree."""
    
    def __init__(self):
        """Initialize AST analyzer."""
        logger.info("ASTAnalyzer initialized")
    
    def parse_code(self, code: str) -> Optional[ast.AST]:
        """Parse code into AST."""
        try:
            return ast.parse(code)
        except SyntaxError as e:
            logger.error(f"Syntax error in code: {e}")
            return None
    
    def analyze(self, code: str) -> Dict[str, Any]:
        """Perform comprehensive AST analysis."""
        tree = self.parse_code(code)
        if tree is None:
            return {"error": "Invalid Python syntax"}
        
        analysis = {
            "functions": self._extract_functions(tree),
            "classes": self._extract_classes(tree),
            "imports": self._extract_imports(tree),
            "calls": self._extract_function_calls(tree),
            "assignments": self._extract_assignments(tree),
            "vulnerabilities": self._detect_ast_vulnerabilities(tree, code)
        }
        
        logger.info(f"AST analysis completed: {len(analysis['functions'])} functions found")
        return analysis
    
    def _extract_functions(self, tree: ast.AST) -> List[Dict[str, Any]]:
        """Extract function definitions from AST."""
        functions = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                functions.append({
                    "name": node.name,
                    "line": node.lineno,
                    "args": [arg.arg for arg in node.args.args],
                    "decorators": [ast.unparse(d) if hasattr(ast, 'unparse') else str(d) 
                                  for d in node.decorator_list]
                })
        return functions
    
    def _extract_classes(self, tree: ast.AST) -> List[Dict[str, Any]]:
        """Extract class definitions from AST."""
        classes = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                classes.append({
                    "name": node.name,
                    "line": node.lineno,
                    "bases": [ast.unparse(b) if hasattr(ast, 'unparse') else str(b) 
                             for b in node.bases]
                })
        return classes
    
    def _extract_imports(self, tree: ast.AST) -> List[Dict[str, Any]]:
        """Extract import statements from AST."""
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append({
                        "module": alias.name,
                        "alias": alias.asname,
                        "line": node.lineno
                    })
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    imports.append({
                        "module": node.module or "",
                        "name": alias.name,
                        "alias": alias.asname,
                        "line": node.lineno
                    })
        return imports
    
    def _extract_function_calls(self, tree: ast.AST) -> List[Dict[str, Any]]:
        """Extract function calls from AST."""
        calls = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                calls.append({
                    "function": func_name,
                    "line": node.lineno,
                    "args_count": len(node.args)
                })
        return calls
    
    def _get_call_name(self, node: ast.Call) -> str:
        """Get function name from call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        else:
            return "unknown"
    
    def _extract_assignments(self, tree: ast.AST) -> List[Dict[str, Any]]:
        """Extract variable assignments from AST."""
        assignments = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        assignments.append({
                            "variable": target.id,
                            "line": node.lineno,
                            "value_type": type(node.value).__name__
                        })
        return assignments
    
    def _detect_ast_vulnerabilities(self, tree: ast.AST, code: str) -> List[Dict[str, Any]]:
        """Detect vulnerabilities using AST analysis."""
        vulnerabilities = []
        lines = code.split('\n')
        
        # Check for dangerous function calls
        dangerous_functions = {
            "eval": "Command injection via eval()",
            "exec": "Command injection via exec()",
            "compile": "Code injection via compile()",
            "__import__": "Dynamic import may be unsafe"
        }
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name in dangerous_functions:
                    vulnerabilities.append({
                        "type": "command_injection",
                        "severity": "critical",
                        "line": node.lineno,
                        "description": dangerous_functions[func_name],
                        "code_snippet": lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
                    })
        
        # Check for string formatting in SQL-like contexts
        vulnerabilities.extend(self._check_sql_injection_ast(tree, code))
        
        # Check for hardcoded secrets
        vulnerabilities.extend(self._check_hardcoded_secrets_ast(tree, code))
        
        return vulnerabilities
    
    def _check_sql_injection_ast(self, tree: ast.AST, code: str) -> List[Dict[str, Any]]:
        """Check for SQL injection patterns using AST."""
        vulnerabilities = []
        lines = code.split('\n')
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if "execute" in func_name.lower() or "query" in func_name.lower():
                    # Check if arguments contain string concatenation
                    for arg in node.args:
                        if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Add):
                            vulnerabilities.append({
                                "type": "sql_injection",
                                "severity": "high",
                                "line": node.lineno,
                                "description": "SQL injection risk: string concatenation in query",
                                "code_snippet": lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
                            })
        
        return vulnerabilities
    
    def _check_hardcoded_secrets_ast(self, tree: ast.AST, code: str) -> List[Dict[str, Any]]:
        """Check for hardcoded secrets using AST."""
        vulnerabilities = []
        lines = code.split('\n')
        secret_keywords = ["password", "secret", "api_key", "token", "key"]
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id.lower()
                        if any(keyword in var_name for keyword in secret_keywords):
                            if isinstance(node.value, (ast.Str, ast.Constant)):
                                value = getattr(node.value, 's', getattr(node.value, 'value', ''))
                                if isinstance(value, str) and len(value) > 8:
                                    vulnerabilities.append({
                                        "type": "hardcoded_secrets",
                                        "severity": "high",
                                        "line": node.lineno,
                                        "description": f"Hardcoded secret detected: {target.id}",
                                        "code_snippet": lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
                                    })
        
        return vulnerabilities
    
    def get_code_structure(self, code: str) -> Dict[str, Any]:
        """Get high-level code structure."""
        tree = self.parse_code(code)
        if tree is None:
            return {"error": "Invalid syntax"}
        
        return {
            "functions": len(self._extract_functions(tree)),
            "classes": len(self._extract_classes(tree)),
            "imports": len(self._extract_imports(tree)),
            "total_lines": len(code.split('\n'))
        }


# Example usage
if __name__ == "__main__":
    analyzer = ASTAnalyzer()
    test_code = """
    import os
    def login(username, password):
        query = "SELECT * FROM users WHERE name = '" + username + "'"
        return query
    """
    
    analysis = analyzer.analyze(test_code)
    print("AST Analysis Results:")
    print(f"Functions: {len(analysis['functions'])}")
    print(f"Vulnerabilities: {len(analysis['vulnerabilities'])}")
    for vuln in analysis['vulnerabilities']:
        print(f"  - {vuln['description']} (Line {vuln['line']})")
