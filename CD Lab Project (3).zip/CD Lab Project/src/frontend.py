"""
Streamlit frontend for the secure code compiler.
"""
import streamlit as st
import sys
import os
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.agent_orchestrator import AgentOrchestrator
from src.explainability import ExplainabilityModule
from src.visualizer import Visualizer
from src.input_validator import InputValidator
from src.rate_limiter import RateLimiter
from src.code_formatter import CodeFormatter
from src.utils import save_code_to_file, format_audit_report
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="Secure Code Compiler",
    page_icon="🔒",
    layout="wide"
)

# Initialize session state
if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = AgentOrchestrator(max_iterations=3)
if "explainer" not in st.session_state:
    st.session_state.explainer = ExplainabilityModule()
if "visualizer" not in st.session_state:
    st.session_state.visualizer = Visualizer()
if "validator" not in st.session_state:
    st.session_state.validator = InputValidator()
if "rate_limiter" not in st.session_state:
    st.session_state.rate_limiter = RateLimiter(max_requests_per_minute=10)
if "formatter" not in st.session_state:
    st.session_state.formatter = CodeFormatter()

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #1f77b4;
        color: white;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

def main():
    """Main Streamlit application."""
    # Header
    st.markdown('<p class="main-header">🔒 Secure Code Compiler</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Natural Language to Secure Code with Agentic AI</p>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.header("About")
        st.info("""
        This compiler converts natural language descriptions into secure, 
        production-ready Python code using Agentic AI.
        
        **Features:**
        - NLP-based intent extraction
        - AI-powered code generation
        - Automated security auditing
        - Vulnerability detection & fixing
        - OWASP Top 10 compliance
        """)
        
        st.header("Settings")
        max_iterations = st.slider("Max Agent Iterations", 1, 5, 3)
        st.session_state.orchestrator.max_iterations = max_iterations
        
        if st.button("Clear Cache"):
            st.session_state.orchestrator.agent.compiler = None
            st.success("Cache cleared!")
    
    # Main content
    tab1, tab2, tab3 = st.tabs(["Code Generation", "Analysis", "Documentation"])
    
    with tab1:
        st.header("Generate Secure Code")
        
        # Input area
        user_input = st.text_area(
            "Enter your code requirement in natural language:",
            height=150,
            placeholder="Example: Create a login function with username and password validation"
        )
        
        col1, col2 = st.columns([1, 4])
        with col1:
            compile_button = st.button("🔒 Compile Secure Code", type="primary", use_container_width=True)
        
        # Process request
        if compile_button and user_input:
            # Validate input
            is_valid, error_msg = st.session_state.validator.validate_user_input(user_input)
            if not is_valid:
                st.error(f"❌ Input Validation Error: {error_msg}")
                st.stop()
            
            # Check rate limit
            user_id = st.session_state.get("user_id", "default")
            allowed, rate_limit_msg = st.session_state.rate_limiter.is_allowed(user_id)
            if not allowed:
                st.error(f"⏱️ Rate Limit: {rate_limit_msg}")
                st.info("Please wait a moment before trying again.")
                st.stop()
            
            with st.spinner("Generating secure code... This may take a few seconds."):
                try:
                    # Execute agent loop
                    result = st.session_state.orchestrator.orchestrate(user_input)
                    st.session_state.last_result = result
                    
                    # Display results
                    st.success("✅ Code generated successfully!")
                    
                    # Format code
                    generated_code = result.get("code", "")
                    formatted_code = st.session_state.formatter.format_code(generated_code)
                    
                    # Code quality analysis
                    quality_analysis = st.session_state.formatter.enhance_code_quality(formatted_code)
                    improvements = st.session_state.formatter.suggest_improvements(formatted_code)
                    
                    # Code output
                    st.subheader("Generated Code")
                    st.code(formatted_code, language="python")
                    
                    # Code quality metrics
                    with st.expander("📊 Code Quality Analysis"):
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Functions", quality_analysis.get("function_count", 0))
                        with col2:
                            st.metric("Lines", quality_analysis.get("line_count", 0))
                        with col3:
                            st.metric("Complexity", quality_analysis.get("complexity_score", 0))
                        
                        if improvements:
                            st.info("💡 Suggestions: " + "; ".join(improvements))
                    
                    # Download button
                    code_file = save_code_to_file(result.get("code", ""))
                    with open(code_file, 'r') as f:
                        st.download_button(
                            label="📥 Download Code",
                            data=f.read(),
                            file_name=f"secure_code_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py",
                            mime="text/x-python"
                        )
                    
                    # Security metrics
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Security Score", f"{result.get('security_score', 0)}/100")
                    with col2:
                        st.metric("Vulnerabilities", len(result.get('vulnerabilities', [])))
                    with col3:
                        st.metric("Iterations", result.get('iterations', 0))
                    with col4:
                        response_time = result.get('metrics', {}).get('response_time', 0)
                        st.metric("Response Time", f"{response_time:.2f}s")
                    
                    # Vulnerabilities section
                    vulnerabilities = result.get('vulnerabilities', [])
                    if vulnerabilities:
                        st.subheader("⚠️ Detected Vulnerabilities")
                        for i, vuln in enumerate(vulnerabilities[:10], 1):
                            with st.expander(f"{i}. {vuln.get('type', 'Unknown')} - {vuln.get('severity', 'Unknown')}"):
                                st.write(f"**Description:** {vuln.get('description', 'N/A')}")
                                st.write(f"**Line:** {vuln.get('line', 'N/A')}")
                                st.code(vuln.get('code_snippet', ''), language='python')
                                st.write(f"**Fix:** {vuln.get('fix_suggestion', 'N/A')}")
                    else:
                        st.success("✅ No vulnerabilities detected! Code is secure.")
                    
                except Exception as e:
                    st.error(f"Error: {str(e)}")
                    logger.error(f"Frontend error: {e}", exc_info=True)
        
        elif compile_button:
            st.warning("Please enter a code requirement first.")
    
    with tab2:
        st.header("Code Analysis")
        
        if "last_result" in st.session_state:
            result = st.session_state.last_result
            
            # Explainability
            st.subheader("Process Explanation")
            explanation = st.session_state.explainer.generate_full_explanation(result)
            st.text_area("Explanation", explanation, height=300)
            
            # Visualizations
            st.subheader("Visualizations")
            
            col1, col2 = st.columns(2)
            with col1:
                if result.get('vulnerabilities'):
                    heatmap_html = st.session_state.visualizer.create_vulnerability_heatmap(
                        result['vulnerabilities']
                    )
                    st.components.v1.html(heatmap_html, height=400)
            
            with col2:
                if result.get('actions_taken'):
                    decision_tree = st.session_state.visualizer.create_agent_decision_tree(
                        result['actions_taken']
                    )
                    st.text(decision_tree)
            
            # Agent trace
            st.subheader("Agent Execution Trace")
            trace = st.session_state.orchestrator.get_execution_trace(result)
            st.text(trace)
        else:
            st.info("Generate code first to see analysis results.")
    
    with tab3:
        st.header("Documentation")
        
        st.subheader("How to Use")
        st.markdown("""
        1. Enter your code requirement in natural language
        2. Click "Compile Secure Code"
        3. Review the generated code and security report
        4. Download the code if needed
        
        **Example Inputs:**
        - "Create a login form with username and password fields"
        - "Build a function to query user data from database"
        - "Generate code for file upload with validation"
        """)
        
        st.subheader("Vulnerability Detection")
        st.markdown("""
        The system detects and fixes:
        - SQL Injection
        - XSS (Cross-Site Scripting)
        - Weak Password Storage
        - Hardcoded Secrets
        - Missing Input Validation
        - Command Injection
        - Path Traversal
        - CSRF (Cross-Site Request Forgery)
        - Broken Authentication
        - Sensitive Data Exposure
        """)
        
        st.subheader("Technology Stack")
        st.markdown("""
        - **Frontend:** Streamlit
        - **NLP/LLM:** Google Gemini API, LangChain
        - **Code Analysis:** AST (Python's ast module)
        - **Testing:** pytest, coverage
        """)

if __name__ == "__main__":
    main()
