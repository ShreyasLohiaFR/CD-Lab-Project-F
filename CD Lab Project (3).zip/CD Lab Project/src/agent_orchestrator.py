"""
Agent orchestrator for managing the autonomous agent loop.
"""
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from .agent import SecurityAgent
from .utils import logger, calculate_metrics


class AgentOrchestrator:
    """Orchestrates the agent loop and manages execution flow."""
    
    def __init__(self, max_iterations: int = 3, timeout_seconds: int = 30):
        """Initialize orchestrator."""
        self.agent = SecurityAgent()
        self.max_iterations = max_iterations
        self.timeout_seconds = timeout_seconds
        logger.info(f"AgentOrchestrator initialized (max_iterations={max_iterations})")
    
    def orchestrate(self, user_input: str) -> Dict[str, Any]:
        """Orchestrate the complete agent workflow."""
        start_time = datetime.now()
        
        try:
            # Execute agent loop
            result = self.agent.execute_agent_loop(user_input, self.max_iterations)
            
            # Calculate metrics
            end_time = datetime.now()
            metrics = calculate_metrics(start_time, end_time, api_calls=result["iterations"])
            
            # Combine results
            final_result = {
                **result,
                "metrics": metrics,
                "status": "success",
                "timestamp": end_time.isoformat()
            }
            
            logger.info(f"Orchestration completed successfully")
            return final_result
            
        except Exception as e:
            logger.error(f"Orchestration error: {e}")
            end_time = datetime.now()
            return {
                "code": "",
                "vulnerabilities": [],
                "is_secure": False,
                "iterations": 0,
                "actions_taken": [],
                "security_score": 0,
                "metrics": calculate_metrics(start_time, end_time),
                "status": "error",
                "error": str(e),
                "timestamp": end_time.isoformat()
            }
    
    def get_execution_trace(self, result: Dict[str, Any]) -> str:
        """Generate human-readable execution trace."""
        trace = []
        trace.append("=== Agent Execution Trace ===\n")
        trace.append(f"Input: {result.get('user_input', 'N/A')}")
        trace.append(f"Iterations: {result.get('iterations', 0)}/{self.max_iterations}")
        trace.append(f"Status: {result.get('status', 'unknown')}")
        trace.append(f"\nActions Taken:")
        
        for action in result.get("actions_taken", []):
            trace.append(f"  - {action}")
        
        trace.append(f"\nFinal Security Score: {result.get('security_score', 0)}/100")
        trace.append(f"Vulnerabilities Found: {len(result.get('vulnerabilities', []))}")
        
        if result.get("metrics"):
            trace.append(f"\nPerformance Metrics:")
            trace.append(f"  - Response Time: {result['metrics'].get('response_time', 0):.2f}s")
            trace.append(f"  - API Calls: {result['metrics'].get('api_calls', 0)}")
        
        return "\n".join(trace)


# Example usage
if __name__ == "__main__":
    orchestrator = AgentOrchestrator(max_iterations=3)
    result = orchestrator.orchestrate("Create a secure login function")
    print(orchestrator.get_execution_trace(result))
