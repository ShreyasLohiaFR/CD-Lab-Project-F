"""
Data flow analysis for tracking tainted variables and data flow vulnerabilities.
"""
import ast
import logging
from typing import List, Dict, Any, Set, Optional
from .ast_analyzer import ASTAnalyzer
from .utils import logger


class DataFlowAnalyzer:
    """Analyze data flow to detect tainted variable vulnerabilities."""
    
    def __init__(self):
        """Initialize data flow analyzer."""
        self.ast_analyzer = ASTAnalyzer()
        self.taint_sources = {"request", "input", "argv", "get", "post", "query", "form"}
        self.taint_sinks = {"execute", "query", "eval", "exec", "system", "open", "render"}
        logger.info("DataFlowAnalyzer initialized")
    
    def analyze_dataflow(self, code: str) -> Dict[str, Any]:
        """Perform data flow analysis."""
        tree = self.ast_analyzer.parse_code(code)
        if tree is None:
            return {"error": "Invalid syntax"}
        
        tainted_vars = self._identify_tainted_variables(tree, code)
        data_flows = self._trace_data_flows(tree, tainted_vars, code)
        vulnerabilities = self._detect_dataflow_vulnerabilities(data_flows, code)
        
        return {
            "tainted_variables": tainted_vars,
            "data_flows": data_flows,
            "vulnerabilities": vulnerabilities,
            "summary": {
                "tainted_count": len(tainted_vars),
                "flow_count": len(data_flows),
                "vulnerability_count": len(vulnerabilities)
            }
        }
    
    def _identify_tainted_variables(self, tree: ast.AST, code: str) -> List[Dict[str, Any]]:
        """Identify variables that receive user input (tainted sources)."""
        tainted = []
        lines = code.split('\n')
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id
                        # Check if assignment comes from taint source
                        if self._is_taint_source(node.value, tree):
                            tainted.append({
                                "variable": var_name,
                                "line": node.lineno,
                                "source": "user_input",
                                "code_snippet": lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
                            })
        
        return tainted
    
    def _is_taint_source(self, node: ast.AST, tree: ast.AST) -> bool:
        """Check if AST node represents a taint source."""
        if isinstance(node, ast.Call):
            func_name = self._get_call_name(node)
            if any(source in func_name.lower() for source in self.taint_sources):
                return True
        
        if isinstance(node, ast.Attribute):
            attr_name = node.attr.lower()
            if any(source in attr_name for source in self.taint_sources):
                return True
        
        return False
    
    def _get_call_name(self, node: ast.Call) -> str:
        """Get function name from call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""
    
    def _trace_data_flows(self, tree: ast.AST, tainted_vars: List[Dict[str, Any]], 
                          code: str) -> List[Dict[str, Any]]:
        """Trace data flows from tainted variables to sinks."""
        flows = []
        tainted_names = {v["variable"] for v in tainted_vars}
        lines = code.split('\n')
        
        # Simple data flow tracking: find where tainted variables are used
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if any(sink in func_name.lower() for sink in self.taint_sinks):
                    # Check if any argument uses tainted variable
                    for arg in node.args:
                        tainted_in_arg = self._check_tainted_in_expr(arg, tainted_names, tree)
                        if tainted_in_arg:
                            flows.append({
                                "source": tainted_in_arg,
                                "sink": func_name,
                                "line": node.lineno,
                                "type": "tainted_to_sink",
                                "code_snippet": lines[node.lineno - 1].strip() if node.lineno <= len(lines) else ""
                            })
        
        return flows
    
    def _check_tainted_in_expr(self, node: ast.AST, tainted_names: Set[str], 
                               tree: ast.AST) -> Optional[str]:
        """Check if expression contains tainted variable."""
        if isinstance(node, ast.Name):
            if node.id in tainted_names:
                return node.id
        
        if isinstance(node, ast.BinOp):
            # Check both sides of binary operation
            left = self._check_tainted_in_expr(node.left, tainted_names, tree)
            if left:
                return left
            right = self._check_tainted_in_expr(node.right, tainted_names, tree)
            if right:
                return right
        
        if isinstance(node, ast.Call):
            # Check arguments
            for arg in node.args:
                result = self._check_tainted_in_expr(arg, tainted_names, tree)
                if result:
                    return result
        
        return None
    
    def _detect_dataflow_vulnerabilities(self, data_flows: List[Dict[str, Any]], 
                                        code: str) -> List[Dict[str, Any]]:
        """Detect vulnerabilities based on data flow analysis."""
        vulnerabilities = []
        lines = code.split('\n')
        
        for flow in data_flows:
            sink = flow["sink"].lower()
            severity = "high"
            vuln_type = "data_flow"
            
            if "execute" in sink or "query" in sink:
                vuln_type = "sql_injection"
                description = f"SQL injection: tainted data '{flow['source']}' flows to '{flow['sink']}'"
            elif "eval" in sink or "exec" in sink:
                vuln_type = "command_injection"
                severity = "critical"
                description = f"Command injection: tainted data '{flow['source']}' flows to '{flow['sink']}'"
            elif "system" in sink or "call" in sink:
                vuln_type = "command_injection"
                description = f"Command injection: tainted data '{flow['source']}' flows to '{flow['sink']}'"
            elif "open" in sink or "file" in sink:
                vuln_type = "path_traversal"
                description = f"Path traversal: tainted data '{flow['source']}' flows to file operation"
            elif "render" in sink:
                vuln_type = "xss"
                description = f"XSS: tainted data '{flow['source']}' flows to template rendering"
            else:
                description = f"Unsanitized data flow: '{flow['source']}' to '{flow['sink']}'"
            
            vulnerabilities.append({
                "type": vuln_type,
                "severity": severity,
                "line": flow["line"],
                "description": description,
                "source": flow["source"],
                "sink": flow["sink"],
                "code_snippet": flow["code_snippet"],
                "fix_suggestion": self._get_dataflow_fix_suggestion(vuln_type)
            })
        
        return vulnerabilities
    
    def _get_dataflow_fix_suggestion(self, vuln_type: str) -> str:
        """Get fix suggestion for data flow vulnerability."""
        suggestions = {
            "sql_injection": "Sanitize input and use parameterized queries",
            "command_injection": "Validate and sanitize input, avoid eval/exec with user data",
            "path_traversal": "Validate file paths, use os.path.join and restrict to safe directories",
            "xss": "Escape and sanitize user input before rendering"
        }
        return suggestions.get(vuln_type, "Sanitize and validate user input before use")
    
    def visualize_dataflow(self, analysis: Dict[str, Any]) -> str:
        """Generate text visualization of data flow."""
        output = []
        output.append("=== Data Flow Analysis ===\n")
        
        output.append(f"Tainted Variables ({analysis['summary']['tainted_count']}):")
        for tainted in analysis['tainted_variables']:
            output.append(f"  - {tainted['variable']} (Line {tainted['line']})")
        
        output.append(f"\nData Flows ({analysis['summary']['flow_count']}):")
        for flow in analysis['data_flows']:
            output.append(f"  {flow['source']} -> {flow['sink']} (Line {flow['line']})")
        
        output.append(f"\nVulnerabilities ({analysis['summary']['vulnerability_count']}):")
        for vuln in analysis['vulnerabilities']:
            output.append(f"  [{vuln['severity'].upper()}] {vuln['description']} (Line {vuln['line']})")
        
        return "\n".join(output)


# Example usage
if __name__ == "__main__":
    analyzer = DataFlowAnalyzer()
    test_code = """
    def process_user_input():
        username = request.form.get('username')
        query = "SELECT * FROM users WHERE name = '" + username + "'"
        cursor.execute(query)
    """
    
    result = analyzer.analyze_dataflow(test_code)
    print(analyzer.visualize_dataflow(result))
