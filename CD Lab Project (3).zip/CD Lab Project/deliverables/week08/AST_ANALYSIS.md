# AST Analysis & Data Flow Documentation

**Week 8 Deliverable**

## AST Analyzer Module

### Features
- Parse Python code into AST
- Extract functions, classes, imports
- Detect vulnerabilities via AST patterns
- Code structure analysis

### Analysis Capabilities
- Function call analysis
- Variable assignment tracking
- Dangerous function detection (eval, exec)
- SQL injection pattern detection

## Data Flow Analyzer Module

### Features
- Identify tainted variables (user input)
- Trace data flows to sinks
- Detect data flow vulnerabilities
- Visualize data flows

### Taint Sources
- request.form
- input()
- sys.argv
- User-provided data

### Taint Sinks
- execute() (SQL)
- eval(), exec()
- os.system()
- open() (file operations)

## Visualization Examples

1. Vulnerability heatmap by type/severity
2. Data flow diagram
3. Code structure tree
4. Security score trend
5. Agent decision tree

## Test Results (5+ Test Cases)

1. ✅ AST parsing valid code
2. ✅ AST parsing invalid code
3. ✅ Function extraction
4. ✅ Data flow tracing
5. ✅ Tainted variable detection
