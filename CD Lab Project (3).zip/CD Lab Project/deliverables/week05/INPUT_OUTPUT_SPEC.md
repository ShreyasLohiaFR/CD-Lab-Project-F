# Input/Output Specification

**Week 5 Deliverable**

## Input Format

### Natural Language Code Requests (English)

**Format**: Free-form text string

**Examples**:
1. "Create a login function with username and password validation"
2. "Build a function to query user data from database"
3. "Generate code for file upload with validation"
4. "Create an API endpoint for user registration"
5. "Build a function to hash passwords securely"

**Constraints**:
- Maximum length: 1000 characters
- Language: English
- Should describe desired functionality clearly

## Output Format

### Code + Audit Report (JSON)

```json
{
  "code": "def login(username, password):\n    ...",
  "vulnerabilities": [
    {
      "type": "sql_injection",
      "severity": "high",
      "line": 10,
      "description": "SQL injection risk",
      "fix_suggestion": "Use parameterized queries"
    }
  ],
  "security_score": 85,
  "is_secure": true,
  "iterations": 2,
  "metrics": {
    "response_time": 8.5,
    "api_calls": 2
  }
}
```

## System Prompt Templates

### Template 1: Security-Enforced Code Generation
```
You are a security-aware code generator. Generate secure Python code that:
- Follows OWASP Top 10 guidelines
- Never includes hardcoded secrets
- Always validates inputs
- Uses parameterized queries
- Implements secure password hashing
```

### Template 2: Vulnerability Detection
```
Analyze this code for security vulnerabilities:
- SQL Injection
- XSS
- Weak password storage
- Hardcoded secrets
Provide JSON report with vulnerabilities.
```

### Template 3: Code Fixing
```
Fix the following security vulnerabilities in this code:
{vulnerabilities}
Return the secure, fixed version.
```

## Vulnerability Taxonomy

1. **SQL Injection** - Unvalidated input in SQL queries
2. **XSS** - Unsanitized output in HTML
3. **Weak Password Storage** - Plain text or weak hashing
4. **Hardcoded Secrets** - API keys, passwords in code
5. **Missing Input Validation** - No validation of user inputs
6. **Command Injection** - User input in system commands
7. **Path Traversal** - Unvalidated file paths
8. **CSRF** - Missing CSRF protection
9. **Broken Authentication** - Weak auth mechanisms
10. **Sensitive Data Exposure** - Secrets in logs/prints

## Sample Input-Output Pairs

### Example 1
**Input**: "Create a login function"
**Output**: Secure login with bcrypt password hashing, input validation

### Example 2
**Input**: "Query database for user"
**Output**: Parameterized query, no SQL injection

### Example 3
**Input**: "File upload handler"
**Output**: Path validation, file type checking, size limits
