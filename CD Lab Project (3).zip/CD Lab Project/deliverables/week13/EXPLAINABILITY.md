# Explainability & Interpretability

**Week 13 Deliverable**

## Explainability Module

### Features
- Code generation explanations
- Agent decision explanations
- Vulnerability explanations
- Security score explanations
- Full process explanations

## Visualization Artifacts

### 1. Code Generation Flowchart
- Shows step-by-step generation process
- Intent extraction → Code generation → Auditing

### 2. Agent Decision Tree
- Visualizes agent decision-making
- Shows iterations and decisions
- ACCEPT/FIX/REGENERATE paths

### 3. Vulnerability Heatmap
- Vulnerabilities by type and severity
- Color-coded severity levels
- Interactive visualization

### 4. Security Compliance Graph
- OWASP Top 10 compliance status
- Guideline-by-guideline breakdown
- Compliance score visualization

### 5. Security Metrics Dashboard
- Response time gauge
- Security score gauge
- Vulnerability count chart
- Cache hit ratio pie chart

### 6. Data Flow Diagram
- Tainted variable tracking
- Data flow to sinks
- Vulnerability paths

## Explanation Examples

### Example 1: Code Generation
```
User Request: "Create a login function"
Extracted Intent:
  - Functionality: User authentication
  - Components: username, password, validation
  - Security Requirements: password hashing, input validation
Generated Code: Secure login with bcrypt hashing
```

### Example 2: Agent Decision
```
Iteration 1: Generated code
Iteration 1: Found 2 high-severity vulnerabilities
Decision: FIX (vulnerabilities detected)
Iteration 2: Fixed code, re-audited
Iteration 2: No vulnerabilities found
Decision: ACCEPT (code is secure)
```

## System Transparency

- All decisions are explainable
- Vulnerability detection reasons provided
- Fix suggestions included
- Security score calculation transparent
- Agent reasoning documented
