# How to Run the Project - Step by Step Guide

## Prerequisites Check

Before starting, make sure you have:
- ✅ Python 3.8 or higher installed
- ✅ pip package manager
- ✅ OpenAI API key (get one from https://platform.openai.com/api-keys)

## Step-by-Step Instructions

### Step 1: Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`, type `cmd` or `powershell`, press Enter
- Or right-click in the project folder and select "Open in Terminal"

**Navigate to project directory:**
```bash
cd "c:\Users\HP\Desktop\CD Lab Project"
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

**Note:** If you get permission errors, use:
```bash
pip install --user -r requirements.txt
```

**Or create a virtual environment (recommended):**
```bash
# Create virtual environment
python -m venv venv

# Activate it (Windows)
venv\Scripts\activate

# Then install dependencies
pip install -r requirements.txt
```

### Step 3: Set Up API Key

**Option A: Using Command Line (Windows)**
```bash
copy .env.example .env
```

**Option B: Manual Creation**
1. Open `.env.example` file
2. Copy its contents
3. Create a new file named `.env` (no extension)
4. Paste the contents
5. Replace `your_openai_api_key_here` with your actual API key:

```
OPENAI_API_KEY=sk-your-actual-api-key-here
```

**Important:** Never share your API key or commit `.env` to git!

### Step 4: Run the Application

You have **3 options** to run the project:

#### Option 1: Web Interface (Recommended - Best Experience)

```bash
streamlit run src/frontend.py
```

**What happens:**
- Streamlit will start a web server
- Your browser will automatically open to `http://localhost:8501`
- If it doesn't open automatically, copy the URL from the terminal

**To stop:** Press `Ctrl + C` in the terminal

#### Option 2: Command Line Interface

```bash
python main.py --input "Create a secure login function with password hashing"
```

**What happens:**
- Code will be generated in the terminal
- Results will be displayed in the console
- Code will be saved to a file automatically

#### Option 3: Launch UI via main.py

```bash
python main.py --ui
```

This is the same as Option 1 but uses the main.py entry point.

### Step 5: Use the Application

#### If using Web Interface (Option 1):

1. **Enter your request** in the text area:
   - Example: "Create a login function with username and password validation"
   - Example: "Build a secure API endpoint for user registration"
   - Example: "Generate code for file upload with validation"

2. **Click "🔒 Compile Secure Code"** button

3. **Wait for processing** (5-10 seconds)

4. **View results:**
   - Generated code (formatted and highlighted)
   - Security score
   - Vulnerability report (if any)
   - Code quality metrics

5. **Download code** if needed using the download button

#### If using Command Line (Option 2):

The output will show:
- Generated code
- Security score
- Vulnerabilities found
- Execution metrics

## Quick Test

Try this simple test to verify everything works:

```bash
python main.py --input "Create a function that adds two numbers"
```

You should see generated code with security analysis.

## Troubleshooting

### Problem: "ModuleNotFoundError" or "No module named 'streamlit'"

**Solution:**
```bash
pip install streamlit openai langchain langchain-openai python-dotenv
```

### Problem: "OPENAI_API_KEY not found"

**Solution:**
1. Make sure `.env` file exists in the project root
2. Check that it contains: `OPENAI_API_KEY=sk-your-key-here`
3. Make sure there are no spaces around the `=` sign
4. Restart the application

### Problem: "Port 8501 is already in use"

**Solution:**
```bash
# Use a different port
streamlit run src/frontend.py --server.port 8502
```

Then open: `http://localhost:8502`

### Problem: "API rate limit exceeded"

**Solution:**
- Wait a few minutes
- Check your OpenAI account usage
- The system has built-in rate limiting

### Problem: "SyntaxError" or import errors

**Solution:**
```bash
# Make sure you're in the project directory
cd "c:\Users\HP\Desktop\CD Lab Project"

# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

### Problem: Python version too old

**Solution:**
- Install Python 3.8 or higher from https://www.python.org/downloads/
- Make sure to check "Add Python to PATH" during installation

## Verification Checklist

After setup, verify everything works:

- [ ] Dependencies installed (`pip list` shows streamlit, openai, etc.)
- [ ] `.env` file exists with valid API key
- [ ] Can run `python --version` and see 3.8+
- [ ] Can run `streamlit --version` successfully
- [ ] Application starts without errors
- [ ] Web interface opens in browser (if using Option 1)

## Example Commands Summary

```bash
# Navigate to project
cd "c:\Users\HP\Desktop\CD Lab Project"

# Install dependencies
pip install -r requirements.txt

# Set up API key (create .env file manually or copy from .env.example)

# Run web interface
streamlit run src/frontend.py

# OR run command line
python main.py --input "Create a login function"

# OR run UI via main.py
python main.py --ui
```

## Getting Help

If you encounter issues:

1. **Check the error message** - it usually tells you what's wrong
2. **Read `QUICK_START.md`** for quick reference
3. **Read `README.md`** for detailed documentation
4. **Check `docs/USER_GUIDE.md`** for usage guide
5. **Review error logs** - check terminal output for details

## Next Steps After Running

Once the application is running:

1. ✅ Try different natural language inputs
2. ✅ Explore the security analysis features
3. ✅ Check code quality metrics
4. ✅ Review the generated code
5. ✅ Test with various security scenarios

## Success Indicators

You'll know it's working when:
- ✅ Web interface opens without errors
- ✅ You can enter text in the input box
- ✅ Clicking "Compile Secure Code" shows a loading spinner
- ✅ Code is generated and displayed
- ✅ Security metrics are shown
- ✅ No error messages appear

---

**That's it! You're ready to use the Secure Code Compiler!** 🚀
