## Full Code Walkthrough + Study Guide (Lab Viva Ready)

**Use this file to actually learn the entire project at code-level.**  
It is written to help you answer questions like “open this file and explain every line”.

This guide is **mapped to your real code** in:
- `main.py`
- `src/` (all modules)
- `docs/` + `deliverables/` (weekly proof)

If your teacher asks “how did you build it”, your answer should follow:
1) problem → 2) architecture → 3) flow of one request → 4) each module → 5) security strategy → 6) testing → 7) results → 8) limitations.

---

## How to study this project (fast but deep)

### Step A — Learn the pipeline first (1 hour)
Memorize this request flow:
1. UI/CLI takes user input
2. Validate input (`InputValidator`)
3. Rate limit (`RateLimiter`)
4. Orchestrate (`AgentOrchestrator`)
5. Agent loop (`SecurityAgent`)
6. Generate code (`CodeCompiler`) using:
   - OpenAI (if available) OR
   - offline secure templates (if no budget)
7. Audit code (`BasicAuditor`)
8. Decide FIX/ACCEPT (agent policy)
9. Show results + explainability + save file

### Step B — Learn files in this order (2–3 hours)
1. `main.py` (entry point + CLI/UI launch)
2. `src/frontend.py` (UI wiring)
3. `src/agent_orchestrator.py` (the “pipeline controller”)
4. `src/agent.py` (the agent loop)
5. `src/compiler.py` (generation + offline fallback)
6. `src/auditor_basic.py` (regex vulnerabilities)
7. `src/ast_analyzer.py` (AST vulnerabilities)
8. `src/dataflow_analyzer.py` (taint/dataflow vulnerabilities)
9. `src/security_enforcer.py` (OWASP-ish policy scoring)
10. `src/input_validator.py`, `src/rate_limiter.py`, `src/code_formatter.py`
11. `src/explainability.py`, `src/visualizer.py`

---

## Part 1 — Entry points (what runs first)

### 1.1 `main.py` (CLI + UI launcher)

**What it does**
- Parses CLI args: `--input`, `--output`, `--iterations`, `--ui`
- If `--ui`: runs Streamlit (`streamlit run src/frontend.py`)
- If `--input`: runs the pipeline via:
  - `AgentOrchestrator(max_iterations=...)`
  - `orchestrator.orchestrate(user_text)`
- Prints generated code + metrics + vulnerability summary
- Saves output to a file with timestamp (`save_code_to_file`)

**What teachers ask**
- “How does your CLI differ from UI?”  
  CLI prints results and saves code; UI shows tabs, charts, and download button.

**Important implementation note (Windows)**
- Console encoding can crash on emoji output. This is why output uses `[OK]` / `[ERROR]` instead of emoji.

---

## Part 2 — UI wiring (Streamlit)

### 2.1 `src/frontend.py` (UI responsibilities)

**Top responsibilities**
- Create Streamlit layout and session state objects:
  - `AgentOrchestrator`
  - `ExplainabilityModule`
  - `Visualizer`
  - `InputValidator`
  - `RateLimiter`
  - `CodeFormatter`
- Validate input before running pipeline
- Run pipeline (`orchestrator.orchestrate(user_input)`)
- Show:
  - formatted generated code
  - security score, vuln count, iterations, response time
  - vulnerability details (expanders)
  - explainability text + agent trace
  - vulnerability heatmap + decision tree

**Where the pipeline is triggered**
- The button “Compile Secure Code” triggers:
  - validation → rate limit → orchestrate → display results

**What teachers ask**
- “Why Streamlit?”  
  Quick UI for demos, easy components (tabs, metrics), minimal boilerplate.

---

## Part 3 — Orchestration (the controller)

### 3.1 `src/agent_orchestrator.py`

**Why this file exists**
- Clean separation: UI/CLI doesn’t need to know details of agent loop.
- Orchestrator:
  - starts timing
  - calls agent loop
  - computes metrics (response time, api_calls)
  - returns a single result dict

**Core method**
- `orchestrate(user_input: str) -> Dict[str, Any]`

**Result fields**
- `code`, `vulnerabilities`, `iterations`, `actions_taken`, `security_score`
- `metrics`: includes response time and api_calls
- `status`: success/error

**What teachers ask**
- “Why return dict instead of custom class?”  
  Lightweight; easy to JSON/log; Streamlit can display directly.

---

## Part 4 — Agent loop (the core intelligence)

### 4.1 `src/agent.py` (SecurityAgent)

**What the “agent” is in this project**
Not a full LangChain tool-calling agent anymore; it’s an **iterative controller**:
- Generate code
- Audit code
- Decide to accept or regenerate/fix

**Important functions**
- `execute_agent_loop(user_input, max_iterations)`
- `decide_action(code, vulnerabilities, iteration, max_iterations)`

**Decision policy (explain exactly)**
- If no vulnerabilities: ACCEPT
- If max iterations reached: ACCEPT (bounded loop)
- If any vulnerability severity is high/critical: FIX
- Else: ACCEPT

**What happens on FIX**
- It calls `compiler.generate_code()` again with “Fix vulnerabilities …” feedback.

**What teachers ask**
- “Why bounded iterations?”  
  Prevent infinite loops and control cost/time.

---

## Part 5 — Code generation (OpenAI + offline templates)

### 5.1 `src/compiler.py` (CodeCompiler)

This is the most important file for explaining “natural language → code”.

**Two modes**
- **Online mode** (OpenAI available):
  - `ChatOpenAI(...).invoke(messages)` is used for:
    - intent extraction
    - code generation
- **Offline mode** (no budget / no network / missing package):
  - `self.llm = None`
  - Generate secure templates via `_generate_offline_template()`

**Key idea for viva**
Even in offline mode, the system still demonstrates:
- input validation
- security-aware output structure
- auditing pipeline
- explainability and UI flow

#### 5.1.1 Initialization logic (how mode is chosen)
During `__init__()`:
- Reads `OFFLINE_MODE`
- Reads `OPENAI_API_KEY`
- If offline or missing key → offline templates
- Else imports `langchain_openai` lazily and constructs LLM client

#### 5.1.2 `extract_intent()`
- Offline: simple heuristic classification (auth/database/file/api)
- Online: uses `INTENT_EXTRACTION_PROMPT` and parses JSON from the model response
- If the online call fails: switches to offline mode

#### 5.1.3 `generate_code()`
Pipeline:
1) ensure intent exists (extract if missing)
2) if offline → template code
3) else send security prompt to LLM and extract code block
4) if LLM fails → OFFLINE_FALLBACK template

#### 5.1.4 Why templates are “secure”
Templates demonstrate:
- parameterized queries for SQL
- proper password hashing via PBKDF2 + constant-time compare
- safe file upload (extension allowlist, size limit, path traversal checks)

**What teachers ask**
- “Why not always templates?”  
  Templates are limited; OpenAI can adapt to arbitrary requirements.

---

## Part 6 — Security auditing (multi-layer)

Your security auditing is *not one technique*; it’s multiple layers.

### 6.1 `src/auditor_basic.py` (regex-based auditor)

**Why regex matters**
- Fast and catches common mistakes immediately.

**How it works**
- Maintains pattern lists per vulnerability type
- Scans whole code with regex
- Creates vulnerability objects:
  - severity, description, line, snippet, fix suggestion
- Deduplicates and sorts by severity

**Examples to mention**
- SQL injection: concatenation or formatting inside execute/query
- command injection: eval/exec usage
- hardcoded secrets: api_key/token literal assignment

### 6.2 `src/ast_analyzer.py` (AST-based)

**Why AST matters**
Regex may miss patterns or generate false positives. AST provides structure:
- exact function calls, assignments, imports
- detects dangerous calls (`eval`, `exec`, `compile`, `__import__`)
- detects SQL concatenation inside execute calls using AST patterns

### 6.3 `src/dataflow_analyzer.py` (taint/dataflow)

**Core idea**
If user-controlled data flows into a dangerous sink, that’s a vulnerability.

Steps:
1. Identify tainted variables (sources like `request.form.get`, `input()`)
2. Track use of these variables in calls (sinks like `execute`, `open`, `render`)
3. Report vulnerabilities with fix suggestions

**What teachers ask**
- “Is this a full static analysis?”  
  No, it’s a simplified taint-tracking heuristic suitable for a lab prototype.

---

## Part 7 — Security enforcement and compliance scoring

### 7.1 `src/security_enforcer.py` (OWASP-ish checks)

**What it does**
- Checks guideline compliance with simple heuristics
- Computes compliance score (percentage of guidelines met)

**How to explain**
This is a *policy layer* to complement the vulnerability detector.

---

## Part 8 — Hardening the app (validation, limiting, formatting)

### 8.1 `src/input_validator.py`
- prevents malicious input like `eval(...)` / `exec(...)` requests
- blocks excessive obfuscation via special character ratio
- sanitizes control characters and null bytes

### 8.2 `src/rate_limiter.py`
- protects API usage: per minute and per hour
- blocks temporarily if exceeded

### 8.3 `src/code_formatter.py`
- improves readability
- provides “quality metrics” and improvement suggestions

---

## Part 9 — Explainability & visualization (how you justify output)

### 9.1 `src/explainability.py`
- explains:
  - extracted intent
  - agent decisions
  - vulnerabilities
  - security score breakdown

### 9.2 `src/visualizer.py`
- vulnerability heatmap (Plotly)
- decision tree (text)
- metrics dashboard
- compliance graph

**Teacher-friendly explanation**
“I didn’t just generate code; I also show *why* the agent accepted it and what security checks happened.”

---

## Part 10 — What to say when asked “how did you make it?”

Use this story (it matches your weekly deliverables):
- Week 1–3: problem + research + SRS
- Week 4: architecture (4 layers) and module plan
- Week 5: prompt design + I/O spec
- Week 6: UI MVP and input validation scaffolding
- Week 7: compiler + basic auditor
- Week 8: AST + dataflow analyzers
- Week 9: agent loop + orchestrator integration
- Week 10: optimizer + OWASP enforcer
- Week 11: tests + coverage
- Week 12: evaluation metrics
- Week 13: explainability + visualization
- Week 14: final integration + polish

The evidence is already in:
- `deliverables/`
- `weekly_progress/`

---

## Part 11 — Viva practice: “open-file” questions and answers

### If they open `src/compiler.py`
- “This file is responsible for NL→code generation. It supports online OpenAI mode and offline templates. The offline mode lets the whole pipeline run without API budget.”

### If they open `src/agent.py`
- “This is the iterative control loop. It generates code, audits it, and decides FIX/ACCEPT. Iterations are bounded for cost/time.”

### If they open `src/auditor_basic.py`
- “This is rule-based detection using regex patterns for common vulnerabilities. It outputs structured vulnerability objects with severity and fix suggestions.”

### If they open `src/ast_analyzer.py` / `src/dataflow_analyzer.py`
- “These provide deeper static analysis: AST catches dangerous calls structurally, and dataflow tracks tainted variables into sinks.”

---

## Part 12 — Running and demo (no budget version)

Use `RUNNING.md`. For no OpenAI budget:
- set `OFFLINE_MODE=true` in `.env`
- run UI: `streamlit run src/frontend.py`
- demo: login/database/file upload template outputs + auditor report

---

## Next upgrade (if you want it even more “full”)

If you want, I can extend this guide further by adding:
- a “trace one request” section with exact variable values at each step
- a “printout” section: what each result dict field means
- a “teacher-viva script” you can memorize (5–7 minutes)

