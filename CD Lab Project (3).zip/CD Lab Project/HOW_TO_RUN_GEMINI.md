# How to Run with Gemini API

This project has been updated to use the Google Gemini API (via `langchain-google-genai` and `google-generativeai`) instead of the OpenAI API.

Follow these instructions to set up and run the application.

## 1. Get a Gemini API Key

1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Sign in with your Google account.
3. Click on "Get API Key" and select "Create API Key in new project" (or an existing project).
4. Copy the generated API Key.

## 2. Set up the Environment

Create a `.env` file in the root directory of the project (if it doesn't exist) and add your API key:

```env
GEMINI_API_KEY=your_copied_api_key_here
```

Optionally, you can also define other environment variables as specified in `src/config.py`:
```env
GEMINI_MODEL=gemini-2.5-pro
GEMINI_TEMPERATURE=0.7


```
**Or create a virtual environment (recommended):**
```bash
# Create virtual environment
python -m venv venv

# Activate it (Windows)
venv\Scripts\activate

## 3. Install Dependencies

Ensure that you have installed the necessary dependencies (especially the new Gemini ones). Running this command will install everything from `requirements.txt`:

```bash
pip install -r requirements.txt
```

## 4. Run the Application

You can start the Streamlit frontend by running:

```bash
streamlit run src/frontend.py
```

## 5. Verify API Connection

If you want to quickly test that your Gemini API key is working through LangChain, you can run the provided test script:

```bash
python test_langchain_gemini.py
```

If it successfully prints a friendly hello from Gemini, you're all set!
