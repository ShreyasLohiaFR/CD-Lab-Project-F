# User Guide

## Getting Started

### Installation

1. **Prerequisites**
   - Python 3.8 or higher
   - pip package manager
   - OpenAI API key

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configuration**
   - Copy `.env.example` to `.env`
   - Add your OpenAI API key:
     ```
     OPENAI_API_KEY=your_api_key_here
     ```

### Running the Application

#### Web Interface (Recommended)

```bash
streamlit run src/frontend.py
```

Then open http://localhost:8501 in your browser.

#### Command Line Interface

```bash
python main.py --input "Create a secure login function"
```

#### Launch UI via main.py

```bash
python main.py --ui
```

## Usage Guide

### Basic Usage

1. **Enter Natural Language Request**
   - Be specific about what you want
   - Include security requirements if needed
   - Examples:
     - "Create a login function with password hashing"
     - "Build a secure API endpoint for user registration"
     - "Generate code for file upload with validation"

2. **Click "Compile Secure Code"**
   - System will process your request
   - This may take 5-10 seconds

3. **Review Results**
   - Generated code (formatted and syntax-highlighted)
   - Security score
   - Vulnerability report (if any)
   - Code quality metrics

4. **Download Code**
   - Click download button to save code
   - Code is ready to use

### Advanced Features

#### Security Analysis Tab
- View detailed vulnerability analysis
- See data flow diagrams
- Review agent execution trace

#### Code Quality
- Automatic code formatting
- Quality metrics
- Improvement suggestions

#### Rate Limiting
- System limits requests to prevent abuse
- 10 requests per minute default
- 100 requests per hour default

## Best Practices

### Writing Effective Requests

✅ **Good Examples:**
- "Create a login function with bcrypt password hashing and input validation"
- "Build a secure database query function using parameterized queries"
- "Generate code for file upload with size limits and type validation"

❌ **Poor Examples:**
- "make login" (too vague)
- "code" (not descriptive)
- "Create a function that does everything" (too broad)

### Understanding Security Reports

- **High/Critical**: Must fix before use
- **Medium**: Should fix for production
- **Low**: Consider fixing for best practices

### Code Quality Tips

- Review generated code before use
- Test in a safe environment first
- Add your own error handling if needed
- Customize for your specific use case

## Troubleshooting

### Common Issues

**"OPENAI_API_KEY not found"**
- Ensure `.env` file exists with your API key
- Check that key is correctly formatted

**"Rate limit exceeded"**
- Wait a few minutes before trying again
- Reduce request frequency

**"Input validation error"**
- Check input length (10-1000 characters)
- Ensure no dangerous patterns in input
- Use plain English descriptions

**"Timeout error"**
- Simplify your request
- Try again (may be temporary API issue)

**"Module not found"**
- Run `pip install -r requirements.txt`
- Check Python version (3.8+)

### Getting Help

1. Check `README.md` for general information
2. Review `docs/DOCUMENTATION.md` for technical details
3. Check error messages for specific issues
4. Review logs in `app.log` (if enabled)

## Examples

### Example 1: Simple Login Function

**Input:**
```
Create a login function with username and password validation
```

**Output:**
- Secure login function
- Password hashing with bcrypt
- Input validation
- Error handling

### Example 2: Database Query

**Input:**
```
Build a function to query user data from database using parameterized queries
```

**Output:**
- Parameterized SQL query
- No SQL injection vulnerabilities
- Proper error handling

### Example 3: File Upload

**Input:**
```
Generate code for secure file upload with size limits and type validation
```

**Output:**
- File upload handler
- Size validation
- Type checking
- Path traversal protection

## Performance Tips

1. **Use Caching**: Similar requests are cached automatically
2. **Keep Requests Simple**: More specific requests = faster generation
3. **Batch Testing**: Test multiple requirements in one session
4. **Monitor Rate Limits**: Check rate limit stats in UI

## Security Notes

- Generated code follows OWASP Top 10 guidelines
- All inputs are validated and sanitized
- Rate limiting prevents abuse
- API keys are never logged or exposed
- Generated code is audited before delivery

## Support

For detailed technical information, see:
- `docs/DOCUMENTATION.md` - Technical documentation
- `docs/API_REFERENCE.md` - API reference
- `docs/ARCHITECTURE.md` - System architecture
