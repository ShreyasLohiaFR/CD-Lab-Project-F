# Technical Documentation

## Overview

The Secure Code Compiler is an intelligent system that converts natural language descriptions into secure, production-ready Python code using Agentic AI.

## Architecture

### System Components

1. **Frontend (Streamlit)**: Web-based user interface
2. **Compiler**: Code generation using LLM
3. **Auditor**: Multi-layer vulnerability detection
4. **Agent**: Autonomous decision-making and fixing
5. **Analyzer**: AST and data flow analysis
6. **Optimizer**: Performance optimization
7. **Enforcer**: Security policy enforcement

## API Reference

### CodeCompiler

```python
compiler = CodeCompiler(model_name="gpt-4-turbo-preview")
code = compiler.generate_code("Create a login function")
```

### BasicAuditor

```python
auditor = BasicAuditor()
vulnerabilities = auditor.audit(code)
is_secure, vulns = auditor.is_secure(code)
```

### SecurityAgent

```python
agent = SecurityAgent()
result = agent.execute_agent_loop("Create secure login", max_iterations=3)
```

## Configuration

### Environment Variables

- `OPENAI_API_KEY`: Required - Your OpenAI API key
- `OPENAI_MODEL`: Optional - Model to use (default: gpt-4-turbo-preview)
- `MAX_ITERATIONS`: Optional - Max agent iterations (default: 3)

## Usage Examples

See README.md for detailed usage instructions.

## Troubleshooting

### Common Issues

1. **API Key Error**: Ensure OPENAI_API_KEY is set in .env
2. **Timeout**: Increase timeout or simplify request
3. **Rate Limits**: Implement caching or wait between requests
