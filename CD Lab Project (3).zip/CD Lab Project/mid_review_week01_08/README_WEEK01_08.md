## CD Lab Mid Review (Weeks 1–8) — Clear “What to show + What to run” Script

This file is a **step-by-step script** for the mid review.

Key point:
- Your runnable project is the **parent folder**: `CD Lab Project`
- This `mid_review_week01_08` folder is just your **guide** for Weeks 1–8.

---

## A) One-time setup (do this at home before review day)

### A1) Make the demo safe (NO OpenAI budget needed)

In the **parent** folder (`CD Lab Project`):

1) Ensure `.env` exists:

```powershell
Copy-Item .\.env.example .\.env
```

2) Open `.env` and set:
- `OFFLINE_MODE=true`
- (keep `OFFLINE_FALLBACK=true`)

This guarantees the demo works even with **no OpenAI credits/network**.

### A2) Activate venv + install requirements

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### A3) Practice 2 commands (these are your only executions)

UI (Week 6 demo):

```powershell
streamlit run .\src\frontend.py
```

CLI (Week 7 demo):

```powershell
python .\main.py --input "Create a secure login function with password hashing"
```

---

## B) Review-day plan (10–12 minutes)

Follow this order exactly:
1) Weeks 1–4: show **deliverables** (docs only, 30–45 sec each)
2) Week 5: show **prompts + I/O spec** (1 min)
3) Week 6: run **Streamlit UI** (2–3 min)
4) Week 7: run **CLI** (2–3 min)
5) Week 8: open **AST + Dataflow** code and explain (2 min; demo only if asked)

---

## C) Week-by-week: what to OPEN + what to SAY + what to RUN

All paths below are relative to the **parent folder** `CD Lab Project`.

### Week 1 — Problem definition + compiler phases

- **OPEN**
  - `deliverables/week01/PROBLEM_DEFINITION.md`
  - `deliverables/week01/COMPILER_PHASES_DIAGRAM.md`
- **SAY (memorize these 2 lines)**
  - “Problem: NL → secure code, but normal generators are not security-aware.”
  - “Pipeline like compiler phases: intent parsing → code generation → security audit → fix loop.”
- **RUN**: nothing

### Week 2 — Literature survey / gap

- **OPEN**
  - `deliverables/week02/LITERATURE_SURVEY.md`
- **SAY (2 lines)**
  - “Compared existing tools like ChatGPT/Copilot.”
  - “Gap: they generate code but don’t automatically audit + fix vulnerabilities.”
- **RUN**: nothing

### Week 3 — SRS + threats

- **OPEN**
  - `deliverables/week03/SRS.md`
- **SAY (2 lines)**
  - “Defined FRs/NFRs and security requirements.”
  - “Included threat model and OWASP Top 10 focus.”
- **RUN**: nothing

### Week 4 — Architecture (4 layers)

- **OPEN**
  - `deliverables/week04/ARCHITECTURE.md`
  - `docs/ARCHITECTURE.md`
- **SAY (2 lines)**
  - “4 layers: UI → intent extraction → code generation → security audit.”
  - “From Week 5 onwards I started implementing these modules.”
- **RUN**: nothing

### Week 5 — Prompts + Input/Output spec + compiler skeleton

- **OPEN**
  - `deliverables/week05/INPUT_OUTPUT_SPEC.md`
  - `src/prompts.py`  (show security constraints list)
  - `src/compiler.py` (show class `CodeCompiler`: intent + generate)
- **SAY (3 lines)**
  - “I fixed the I/O format and wrote security-enforced prompts.”
  - “`CodeCompiler` is the generator: it extracts intent then generates secure code.”
  - “If OpenAI is unavailable, OFFLINE_MODE generates secure templates so the pipeline still runs.”
- **RUN**: nothing

### Week 6 — Frontend MVP + validation

- **OPEN**
  - `src/frontend.py` (show UI controls + where it calls the pipeline)
  - `src/input_validator.py` (show dangerous pattern checks)
  - `src/rate_limiter.py` (optional: show cost protection)
- **SAY (2 lines)**
  - “Streamlit UI takes NL requirement, validates it, then runs the pipeline.”
  - “Validation blocks unsafe inputs like eval/exec patterns and prevents abuse via rate limiting.”
- **RUN (in PowerShell, from parent folder)**

```powershell
streamlit run .\src\frontend.py
```

- **SHOW in browser**
  - Enter: `Create a secure login function with password hashing`
  - Click compile
  - Show output code + security score

### Week 7 — Core logic: generation + basic auditor

- **OPEN**
  - `src/compiler.py` (generate_code flow)
  - `src/auditor_basic.py` (regex patterns, severity, line number extraction)
  - `main.py` (CLI path: `--input`)
- **SAY (3 lines)**
  - “Week 7 gives end-to-end: NL → code generation + security audit report.”
  - “Auditor detects SQL injection, XSS, weak password storage, hardcoded secrets, command injection, etc.”
  - “Output includes vulnerabilities, score, and saved code file.”
- **RUN (in PowerShell, from parent folder)**

```powershell
python .\main.py --input "Create a secure login function with password hashing"
```

- **SHOW in terminal**
  - “Generated Code”
  - “[OK] No vulnerabilities detected!” (or list of vulnerabilities if shown)
  - “Code saved to: generated_code_...py”

### Week 8 — AST + Dataflow analyzers (static analysis depth)

- **OPEN**
  - `src/ast_analyzer.py`
  - `src/dataflow_analyzer.py`
  - `deliverables/week08/AST_ANALYSIS.md` (if present)
- **SAY (3 lines)**
  - “Regex is fast but shallow; AST analysis is structure-aware (real function calls/assignments).”
  - “Dataflow marks user input as tainted and checks if it reaches sinks like execute/open/eval.”
  - “This catches deeper vulnerabilities beyond simple string matching.”

#### Optional Week 8 execution (ONLY if teacher forces you)

1) Create a temporary file in the **parent folder** named `week08_demo.py`
2) Paste this:

```python
from src.ast_analyzer import ASTAnalyzer
from src.dataflow_analyzer import DataFlowAnalyzer

code = """
def process():
    username = request.form.get('username')
    query = "SELECT * FROM users WHERE name = '" + username + "'"
    cursor.execute(query)
"""

print("=== AST Analyzer ===")
ast_result = ASTAnalyzer().analyze(code)
print(ast_result.get("vulnerabilities", []))

print("\n=== Dataflow Analyzer ===")
df_result = DataFlowAnalyzer().analyze_dataflow(code)
print(df_result.get("vulnerabilities", []))
```

3) Run:

```powershell
python .\week08_demo.py
```

---

## D) If teacher says: “show Week 1–8 code only”

Say exactly:
- “For the mid review I will only open and explain the Week 1–8 files listed in this script.”
- “Later modules are part of Week 9+ final integration, but I’m not using them for this evaluation.”

---

## E) Quick copy-paste commands (parent folder)

```powershell
streamlit run .\src\frontend.py
python .\main.py --input "Create a secure login function with password hashing"
```

## CD Lab Mid Review – Weeks 1–8 Snapshot

You can move or zip this `mid_review_week01_08` folder and use it as the **entry point** for your Week‑1‑to‑8 review. The actual runnable code still lives one level up (in the main `CD Lab Project` folder), but this folder tells you exactly **what to open and run** for the mid review.

---

## 1. What teachers will evaluate (as per message)

- Progress **up to Week 8** (not full project)
- **Folders and submissions** for each week
- **Code execution** (simple demos)
- **Explanation of code**

This folder helps you show only the relevant pieces for Weeks 1–8.

---

## 2. Where the real project code is

The full project (including Week‑8 code and later weeks) is still here:

- `..` (parent folder): `CD Lab Project`
  - `src/` – all Python modules
  - `docs/`
  - `deliverables/`
  - `weekly_progress/`
  - `main.py`
  - `requirements.txt`

For mid review, **you will keep running code from the parent folder**, but you only **show/explain** the parts listed below.

---

## 3. What to show for each week (1–8)

Use this as your mini script. All paths below are relative to the **parent** project folder.

### Week 1 — Problem understanding
- **Show files**:
  - `deliverables/week01/PROBLEM_DEFINITION.md`
  - `deliverables/week01/COMPILER_PHASES_DIAGRAM.md`
- **Say**:
  - “I defined the problem: converting natural language to secure code.”
  - “I mapped it to compiler phases: parse intent → generate code → audit → fix.”

### Week 2 — Literature survey
- **Show files**:
  - `deliverables/week02/LITERATURE_SURVEY.md`
- **Say**:
  - “I compared ChatGPT, Copilot, and existing secure-code tools.”
  - “Gap: they generate code but don’t automatically fix vulnerabilities.”

### Week 3 — SRS & threats
- **Show files**:
  - `deliverables/week03/SRS.md`
- **Say**:
  - “I wrote functional + non-functional requirements.”
  - “Included threat model and OWASP Top 10 as requirements.”

### Week 4 — Architecture & design
- **Show files**:
  - `deliverables/week04/ARCHITECTURE.md`
  - `docs/ARCHITECTURE.md`
- **Say**:
  - “I finalized a 4-layer architecture: UI → NLP/intent → generation → security audit/agent.”
  - Optionally show `main.py` as a stub entry point.

### Week 5 — Prompts & I/O spec (+ compiler skeleton)
- **Show files**:
  - `src/prompts.py`
  - `deliverables/week05/INPUT_OUTPUT_SPEC.md`
- **Code to open**:
  - `src/compiler.py` – briefly show class `CodeCompiler` (even if final version is richer).
- **Say**:
  - “I fixed the structure of inputs/outputs and wrote security-focused prompts.”
  - “I created a compiler skeleton that takes NL input and returns code.”

### Week 6 — Frontend MVP + basic validation
- **Show files**:
  - `src/frontend.py` – focus on the UI layout and how it reads user text.
  - `src/input_validator.py` – show validation logic.
- **Demo command** (from parent folder):
  - `streamlit run src/frontend.py`
- **Say**:
  - “I built a basic Streamlit UI: textarea + button + output.”
  - “I added input validation to block dangerous or invalid requests.”

### Week 7 — Core logic: compiler + basic auditor
- **Show files**:
  - `src/compiler.py` – explain how NL → code generation works (OpenAI + offline mode).
  - `src/auditor_basic.py` – explain regex-based vulnerability detection.
- **Demo command** (from parent folder, CLI):
  - `python main.py --input "Create a login function with username and password"`
- **Say**:
  - “By Week 7, I can generate code from natural language and run a basic security audit.”
  - “The auditor detects SQL injection, XSS, weak passwords, hardcoded secrets, etc.”

### Week 8 — AST & dataflow analyzers
- **Show files**:
  - `src/ast_analyzer.py`
  - `src/dataflow_analyzer.py`
  - `deliverables/week08/AST_ANALYSIS.md` (if present)
- **Demo idea**:
  - Write a tiny Python snippet inside a temporary script or REPL:
    - import `ASTAnalyzer` / `DataFlowAnalyzer`
    - run `analyze()` / `analyze_dataflow()` on a small vulnerable function
    - print vulnerabilities.
- **Say**:
  - “I added deeper static analysis with AST and taint-style dataflow to catch more subtle vulnerabilities.”

---

## 4. How to answer “show me the code for Week 1–8 only”

Explain to the teacher:
- “This is my **full project folder**. For Weeks 1–8 I’ll only open and explain the files listed above.”
- “Later weeks (agent loop, optimizer, explainability, visualizer, tests) are already implemented but are for Week 9+ and final submission.”

You do **not** need to delete any files; just:
- Open only the Week‑1‑8 files when asked.
- Use this `README_WEEK01_08.md` as your quick reference.

---

## 5. Quick commands (mid‑review)

From the parent project folder:

- **Run UI (to show Week 6+ capability)**:
  ```powershell
  streamlit run src/frontend.py
  ```

- **Run CLI (to show Week 7 codegen + auditor)**:
  ```powershell
  python main.py --input "Create a secure login function with password hashing"
  ```

Make sure your virtual environment is activated and requirements are installed (see `RUNNING.md` in the parent folder).

