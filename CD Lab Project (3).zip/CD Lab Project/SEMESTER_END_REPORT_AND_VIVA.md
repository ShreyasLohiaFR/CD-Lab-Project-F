## End-to-End Natural Language to Secure Code Compiler with Agentic AI

**Student**: Shreyas Prakash Lohia  
**Roll No.**: 24CSB0B70  
**Course**: Compiler Design / Advanced Systems Programming (Lab Project)  
**Semester**: 4  
**Repository/Folder**: `CD Lab Project` (Windows + Python + Streamlit)

This document is an **all-in-one semester-end report + viva/Q&A guide**. It explains:
- what the project does (problem, motivation, scope)
- how the system is designed (architecture + modules)
- how the pipeline works end-to-end (UI → intent → generation → audit → agent loop)
- what security mechanisms were implemented (regex + AST + dataflow)
- how to run/demo/test it (including **no OpenAI budget/offline mode**)
- what results/metrics you can claim (and how to justify them)
- common questions your evaluator may ask (with prepared answers)

---

## Table of contents

- Project abstract & problem statement
- Goals, scope, and assumptions
- System architecture (4-layer) and data flow
- Module-by-module explanation (what each file does)
- Agentic loop (decision logic, iteration control)
- Security auditing approach (regex, AST, dataflow)
- Input validation, rate limiting, formatting, logging
- Configuration (`.env`) and modes (OpenAI vs offline fallback)
- How to run (UI + CLI) and how to demo weekly deliverables
- Testing strategy and results (unit, security tests, integration)
- Evaluation & benchmarking
- Limitations and future improvements
- Viva / Q&A cheat sheet
- Appendix: quick commands and file map

**Also read**: `FULL_CODE_WALKTHROUGH_STUDY_GUIDE.md` for the full code-level explanation (file-by-file, lab viva style).

---

## Project abstract

Modern LLM-based code generation is fast, but it often produces insecure code (SQL injection, hardcoded secrets, weak password storage, etc.). This project implements a **secure-code “compiler” pipeline** that takes a **natural language requirement** and outputs **secure, production-style Python code**. The system integrates:
- an **intent extraction** stage (NLP-like step using LLM when available)
- an **LLM code generator** (OpenAI via LangChain)
- a **multi-layer security auditor** (rule-based patterns + AST checks + dataflow checks)
- an **agentic loop** that can iterate and fix issues automatically
- a **Streamlit UI** plus a CLI entry point

If OpenAI credits/budget are unavailable, the system can run in **OFFLINE_MODE** and still demonstrate the end-to-end pipeline using **secure template generation**.

---

## Problem statement (what you solved)

### Core problem
- Natural language → code is easy with LLMs, but **security is not guaranteed**.
- Manual security review is expensive and slow for student/prototype workflows.
- Goal: Make security **built-in** to generation + auditing + (optionally) auto-fixing.

### Why call it a “compiler” (your justification)
Even though the input is English (not a programming language), the pipeline mirrors a compiler:
- **Front-end**: parse intent from natural language (like lexical/semantic analysis)
- **Middle-end**: generate an intermediate implementation (draft code)
- **Back-end**: optimize/format output + enforce security policies
- **Verification**: static checks via security auditing (like semantic/type checks)
- **Iterative refinement**: agent loop (like repeated compilation passes)

---

## Goals, scope, and assumptions

### Goals
- **G1**: Convert natural language requirements to Python code.
- **G2**: Detect common security vulnerabilities (10+ categories).
- **G3**: Improve code quality (formatting, docstrings hints, metrics).
- **G4**: Provide a usable UI + CLI.
- **G5**: Provide explainability of actions taken and security score.

### Scope (what the system focuses on)
- Output language: **Python**
- UI: **Streamlit**
- Security analysis: lightweight static analysis (regex + AST + dataflow heuristics)
- Agentic behavior: iterative generation/audit/fix loop (bounded iterations)

### Assumptions
- The generated code is “secure by default”, but still should be reviewed before production.
- The security auditor is **heuristic** (good coverage for common patterns, not perfect).
- When OpenAI is unavailable, offline templates allow demonstration of pipeline + security checks.

---

## High-level architecture (4-layer)

### Layers
1. **Frontend layer** (`src/frontend.py`): Streamlit web UI (input, run, show code + report)
2. **NLP / intent layer** (`src/compiler.py` intent extraction): extract structured intent
3. **Code generation layer** (`src/compiler.py`): LLM generation (or offline template fallback)
4. **Security audit + agent layer** (`src/auditor_basic.py`, `src/ast_analyzer.py`, `src/dataflow_analyzer.py`, `src/agent.py`, `src/agent_orchestrator.py`)

### Module dependency chain (simplified)
`frontend.py` → `agent_orchestrator.py` → `agent.py` → (`compiler.py` + `auditor_basic.py`)

---

## End-to-end data flow (what happens on a request)

### UI flow (Streamlit)
1. User types English requirement in UI
2. `InputValidator.validate_user_input()` blocks dangerous/abusive inputs
3. `RateLimiter.is_allowed()` prevents spam/cost abuse
4. `AgentOrchestrator.orchestrate()` runs the agent loop
5. Output is shown:
   - formatted code (`CodeFormatter.format_code()`)
   - security score + vulnerabilities list
   - explainability text + visuals (heatmap/decision tree)

### CLI flow (`main.py`)
1. `python main.py --input "..."` triggers agent orchestrator
2. Prints generated code + metrics + vulnerabilities
3. Saves generated code to a timestamped file

---

## Key modules (file-by-file explanation)

### Entry points
- **`main.py`**
  - CLI mode: `--input`, `--output`, `--iterations`
  - UI mode: `--ui` launches Streamlit
  - Prints summary + saves output code

- **`src/frontend.py`**
  - Streamlit UI with tabs:
    - Code Generation
    - Analysis (explainability + visuals)
    - Documentation (usage guidance)
  - Wires together: orchestrator, validator, rate limiter, formatter, visualizer, explainability

### Orchestration & agent
- **`src/agent_orchestrator.py`**
  - Single entry to run the “agent workflow”
  - Measures time, returns structured result object with metrics and status

- **`src/agent.py`**
  - Implements the iterative **agent loop**
  - Core logic:
    - generate code
    - audit vulnerabilities
    - decide whether to FIX or ACCEPT (bounded by max iterations)

### Code generation
- **`src/compiler.py`** (`CodeCompiler`)
  - `extract_intent()`: converts text into structured fields (LLM or offline heuristic)
  - `generate_code()`: calls OpenAI model via LangChain when available
  - **OFFLINE_MODE**: returns secure template code (login/db/file upload/generic skeleton)
  - **OFFLINE_FALLBACK**: if OpenAI fails (quota/network), falls back to offline templates

### Security auditing
- **`src/auditor_basic.py`** (`BasicAuditor`)
  - Regex-based checks for:
    - SQL injection
    - XSS
    - weak password storage
    - hardcoded secrets
    - missing input validation (heuristic)
    - command injection (`eval`, `exec`, `os.system`, etc.)
    - path traversal
    - CSRF/broken auth/sensitive exposure heuristics
  - Produces vulnerability objects: type, severity, line, snippet, fix suggestion

- **`src/ast_analyzer.py`** (`ASTAnalyzer`)
  - Parses code to AST; extracts:
    - functions, classes, imports, calls, assignments
  - Detects:
    - dangerous calls (`eval`, `exec`, `compile`, `__import__`)
    - SQL injection patterns via AST (string concatenation passed to execute/query)
    - hardcoded secrets via assignments to `password`, `token`, `api_key` variables

- **`src/dataflow_analyzer.py`** (`DataFlowAnalyzer`)
  - Tracks **tainted variables** from sources like `request`, `input`, `argv`, etc.
  - Traces flow into sinks like `execute`, `eval`, `open`, `render`
  - Converts flows into vulnerabilities with severity + fix suggestions

### Security enforcement (policy-like checks)
- **`src/security_enforcer.py`** (`SecurityEnforcer`)
  - Lightweight OWASP Top 10 compliance scoring/checks
  - Adds a “policy layer” beyond pattern matching

### UX & hardening helpers
- **`src/input_validator.py`** (`InputValidator`)
  - protects the system from unsafe inputs (code injection attempts / obfuscation)
  - length bounds, special-character ratio checks, dangerous pattern checks

- **`src/rate_limiter.py`** (`RateLimiter`)
  - protects cost + performance: per-minute and per-hour limits

- **`src/code_formatter.py`** (`CodeFormatter`)
  - light formatting: reduce blank lines, fix spacing
  - quality analysis: counts functions/classes/lines, “complexity” heuristic
  - suggestions: add docstrings, type hints, refactor complex code

### Explainability & visualization
- **`src/explainability.py`** (`ExplainabilityModule`)
  - “why did the agent accept/fix?”, “how is security score computed?”
  - produces a readable trace you can paste in reports

- **`src/visualizer.py`** (`Visualizer`)
  - vulnerability heatmap (Plotly)
  - decision tree text output
  - metrics dashboard (Plotly)
  - compliance graph

### Configuration & utilities
- **`src/config.py`** (`Config`)
  - reads `.env` vars (OpenAI key/model, max iterations, toggles)
  - validates configuration; includes **OFFLINE_MODE**

- **`src/utils.py`**
  - environment helpers, logging, save generated code, metrics helpers

---

## Agentic AI loop (how it “thinks”)

### Why an agent loop?
LLM output can be insecure even if prompted. So the system:
- generates code
- audits code
- if high/critical vulnerabilities exist, attempts to fix by regenerating with feedback
- stops when secure enough or when max iterations is reached

### Core decision policy (current implementation)
- If **no vulnerabilities**: ACCEPT
- If reached **max iterations**: ACCEPT (return best effort)
- If any vulnerability with severity **high/critical**: FIX
- Else: ACCEPT

### Why bounded iterations?
To avoid:
- infinite loops
- uncontrolled cost (API budget)
- poor UX

---

## Security approach (what you can confidently explain)

### 1) Prompt-level security
`src/prompts.py` enforces constraints in the generation prompt:
- no hardcoded secrets
- always validate/sanitize inputs
- parameterized DB queries
- secure password hashing recommendations (bcrypt/argon2)

### 2) Static pattern auditing (regex)
`BasicAuditor` catches “common real-world mistakes” quickly:
- concatenated SQL strings
- innerHTML assignment patterns
- `eval/exec`
- hardcoded secrets/tokens

### 3) AST-based semantic checks
AST analysis catches:
- dangerous calls and their exact line numbers
- structural code facts (imports, assignments)

### 4) Dataflow (taint) checks
Tracks if “user-controlled data” reaches dangerous sinks:
- tainted → `execute()` ⇒ SQL injection
- tainted → `open()` ⇒ path traversal
- tainted → `eval/exec` ⇒ command injection

### 5) OWASP compliance scoring (policy layer)
Provides a compliance “summary score” and violations list.

---

## Configuration and running modes

### `.env` variables (main ones)
- `OPENAI_API_KEY`: OpenAI key (required if not offline)
- `OPENAI_MODEL`: default `gpt-4-turbo-preview`
- `OPENAI_TEMPERATURE`: default 0.7
- `MAX_ITERATIONS`: default 3
- `OFFLINE_MODE=true|false`: **offline template generation**
- `OFFLINE_FALLBACK=true|false`: fallback to offline when OpenAI fails

### Why OFFLINE_MODE exists (what to say)
It ensures you can:
- demonstrate pipeline without paid credits
- run tests and demos offline
- keep the project “presentable” even when network/quota fails

---

## How to run (Windows PowerShell)

Use the step-by-step guide in:
- `RUNNING.md`

Quick commands (summary):
- UI:
  - `streamlit run .\src\frontend.py`
- CLI:
  - `python .\main.py --input "Create a secure login function with password hashing"`

---

## Weekly deliverables: how to explain “how I did it”

Your folder already contains:
- `deliverables/` (week-by-week documents)
- `weekly_progress/` (week-by-week demo scripts and outputs)

A ready mapping of what to show each week is in:
- `deliverables/progression/WEEKLY_CODE_PROGRESSION.md`

What to say in a sentence:
- Weeks 1–4: docs/research/architecture
- Weeks 5–7: prompts + UI + core generation + basic auditor
- Week 8: AST + dataflow analyzers
- Week 9: agent loop + orchestrator
- Week 10: optimization + OWASP enforcement
- Week 11: testing + coverage
- Week 12: evaluation & benchmarking
- Week 13: explainability & visualizations
- Week 14: final integration & polish

---

## Testing strategy (what you can say in viva)

### What was tested
- unit tests for each core module (compiler, auditor, analyzers)
- security tests for vulnerability detection patterns
- integration tests for end-to-end pipeline

### Reported results (from deliverables)
- 50+ test cases
- ~82% code coverage target met
- known failures: tests requiring network/API key (handled with mocks/skip/fallback)

(See `deliverables/week11/TEST_RESULTS.md`.)

---

## Evaluation & benchmarking (how to defend your claims)

Your evaluation document (`deliverables/week12/EVALUATION.md`) compares:
- baseline AI tools (ChatGPT/Copilot) vs your system
- metrics:
  - security score
  - vulnerability detection rate
  - auto-fixing capability
  - response time
  - cost/request

How to explain the “win”:
- Baselines generate code but **don’t run a security auditor loop** automatically.
- Your system adds **security constraints + multi-layer auditing + agentic iteration**.

---

## Limitations (be honest; it helps in viva)

- The “auditor” is not a full static analyzer; it uses heuristics.
- Dataflow tracking is simplified and may miss complex flows or report false positives.
- Generated code correctness depends on prompt quality and model behavior.
- Offline mode produces templates; it demonstrates security structure but is not “true NL→code intelligence”.

---

## Future enhancements (good viva answers)

- Add support for other languages (JS/Java)
- Add stronger IR/CFG-based analysis (control-flow graphs)
- Integrate Bandit/Semgrep-like analyzers
- CI/CD integration (pre-commit security checks)
- Better agent decision policy (acceptance thresholds by severity/type)
- Unit tests that mock OpenAI calls deterministically

---

## Viva / Q&A cheat sheet (common questions + strong answers)

### Q1: Why is this a compiler project?
**A**: It follows compiler-like phases: parse intent → generate implementation → audit/verify → refine output. The “source language” is natural language; the “target language” is secure Python code.

### Q2: What are your compiler phases?
**A**:
- Phase 1: intent extraction (front-end)
- Phase 2: secure code generation (codegen)
- Phase 3: security auditing (verification)
- Phase 4: agentic fixing loop (iterative passes)

### Q3: How do you ensure security?
**A**: Multiple layers:
- security constraints in the generation prompt
- regex auditor for common vulnerabilities
- AST checks for dangerous calls and secret assignments
- dataflow/taint tracking from sources to sinks
- OWASP compliance scoring

### Q4: What vulnerabilities do you detect?
**A**: SQL injection, XSS, weak password storage, hardcoded secrets, missing validation heuristics, command injection (`eval/exec/os.system`), path traversal, CSRF heuristics, broken authentication heuristics, sensitive data exposure.

### Q5: How does the agent decide FIX vs ACCEPT?
**A**: If high/critical vulnerabilities exist and we still have iterations left, it chooses FIX; otherwise it accepts. This keeps the loop bounded and cost-controlled.

### Q6: Why do you need rate limiting?
**A**: To prevent abuse and to control API cost; also to keep the UI responsive under repeated requests.

### Q7: What happens if OpenAI quota/network fails?
**A**: The system can run in OFFLINE_MODE (or OFFLINE_FALLBACK) which generates secure templates without OpenAI, so the pipeline can still be demonstrated end-to-end.

### Q8: What metrics do you report?
**A**: Response time, security score, vulnerability count, iteration count, and evaluation metrics (detection rate, false positives, cost/request).

### Q9: Why AST + regex both?
**A**: Regex is fast and catches many “surface-level” issues; AST adds structure-aware detection (actual function calls/assignments) and reduces some false positives.

### Q10: What is “dataflow/taint analysis” in your project?
**A**: Identify variables derived from user input (“tainted”), trace where they are used, and flag if they reach dangerous sinks like SQL execution or file operations.

---

## Appendix A: Quick file map (what to open during explanation)

- UI: `src/frontend.py`
- Pipeline entry: `src/agent_orchestrator.py`
- Agent loop: `src/agent.py`
- Codegen: `src/compiler.py`
- Regex audit: `src/auditor_basic.py`
- AST: `src/ast_analyzer.py`
- Dataflow: `src/dataflow_analyzer.py`
- OWASP policy: `src/security_enforcer.py`
- Input validation: `src/input_validator.py`
- Rate limiting: `src/rate_limiter.py`
- Formatting/quality: `src/code_formatter.py`
- Explainability: `src/explainability.py`
- Visuals: `src/visualizer.py`
- Run guide: `RUNNING.md`

---

## Appendix B: Demo script (fast)

### Demo 1 (UI)
1. `streamlit run src/frontend.py`
2. Input: “Create a secure login function with password hashing”
3. Show:
   - generated code
   - vulnerability list (or “none”)
   - security score + decision trace

### Demo 2 (CLI)
1. `python main.py --input "Build a secure database query function using parameterized queries"`
2. Show output file saved + printed security score.

