from pathlib import Path


def main() -> None:
    print("WEEK 03 DEMO: Requirements & Threat Analysis")
    print("-" * 60)
    print("This week is specification-focused.")
    print("Deliverable:")
    print("- deliverables/week03/SRS.md")
    print("")
    print("Key items:")
    print("- FR1: accept NL input")
    print("- FR3: generate secure Python")
    print("- FR4–FR13: detect 10+ vuln types")
    print("- FR14: agent fixes vulnerabilities")
    print("- FR15: OWASP Top 10 compliance")
    print("- Threats: API key exposure, injection, DoS, data leakage, model poisoning")

    root = Path(__file__).resolve().parents[2]
    p = root / "deliverables" / "week03" / "SRS.md"
    print(f"OK exists: {p.exists()} -> {p}")


if __name__ == "__main__":
    main()