# Week 03 — What to show

## Show these deliverables
- `deliverables/week03/SRS.md`

## What to say
- 15 functional requirements (FR1–FR15)
- 8+ non-functional requirements (performance, cost, accuracy)
- Threat model with mitigations

## Demo
Run:

```powershell
python .\weekly_progress\week03\run_demo.py
```