from pathlib import Path


def main() -> None:
    print("WEEK 04 DEMO: Architecture & Design")
    print("-" * 60)
    print("This week is design-focused.")
    print("Deliverable:")
    print("- deliverables/week04/ARCHITECTURE.md")
    print("")
    print("Architecture (4 layers):")
    print("1) Streamlit UI")
    print("2) NLP / intent extraction")
    print("3) LLM code generation")
    print("4) Security audit + agent loop")

    root = Path(__file__).resolve().parents[2]
    p = root / "deliverables" / "week04" / "ARCHITECTURE.md"
    print(f"OK exists: {p.exists()} -> {p}")


if __name__ == "__main__":
    main()