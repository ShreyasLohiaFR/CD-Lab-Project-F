# Week 04 — What to show

## Show these deliverables
- `deliverables/week04/ARCHITECTURE.md`

## What to say
- 4-layer architecture: Frontend → NLP → Code Generation → Security Audit/Agent
- Data flow and module interactions
- Tech stack justification

## Demo
Run:

```powershell
python .\weekly_progress\week04\run_demo.py
```