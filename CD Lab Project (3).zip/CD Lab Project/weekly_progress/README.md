# Weekly Progress (Week 01 → Week 14)

This folder lets you **show week-by-week outputs separately** (as teachers check weekly progress).

Each week contains:
- `WHAT_TO_SHOW.md` → what to open/say to teacher
- `run_demo.py` → runs a demo for that week (no UI needed)
- `DEMO_OUTPUT.txt` → saved output you can show quickly

## How to run (PowerShell)

From project root:

```powershell
cd "C:\Users\HP\Desktop\CD Lab Project"
```

Run a week demo and save output (captures both output + errors):

```powershell
python .\weekly_progress\week01\run_demo.py *> .\weekly_progress\week01\DEMO_OUTPUT.txt
```

Repeat for other weeks by changing `week01` to `week02`, etc.

## Notes
- Weeks 1–4 are mostly **documentation weeks** (no big code expected).
- From Week 5 onward, demos show increasing functionality.
- Week 14 is the **final full system** (run Streamlit from root).