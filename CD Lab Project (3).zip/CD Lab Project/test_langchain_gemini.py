from dotenv import load_dotenv
load_dotenv()

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage

# Initialize the chat model
chat = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.7)

# Ask the model something
response = chat.invoke("Say hello in a friendly way.")

# Print the response
print("Gemini says:", response.content)
